<?php

/* TO DOs:
Corrigir todos os erros PHP




Colocar contato de e-mail
Fazer forma de exibição em tabela ordenável
Fazer forma de download
Fazer tudo via API com GEO
Validação javascript e PHP do formulario
Ver erros PHP
Mudar de mysql fetch para PDO 
Estruturar Javascripts nos locais corretos (estão dispersos)
1) Cadastrar instituição
2) Cadastrar cursos
 - Primeiramente via e-mail mesmo preenchendo um documento padrão e importando manualmente
 - Depois uma tela especifica da instituição para cadastro de cursos e aprovação do admin (eg.: http://<mapa>/instituicao/cadastrarcurso)
Fazer refactoring do code ajustando tudo que está bagunçado e organizando os códigos
consertar erros cosméticos na página após troca de versão do bootstrap.
Pesquisa por nome do curso
local para colocar manualmente lat/long
 


Futuro:
Integração com demandas
Integração com startup de curriculums, etc... (deve ser aberto via API para qualquer um para não dar problema legal)



*/

//$typesFileName = "categories.json";

if(!file_exists('include/db.php')) require_once('installer.php');
include_once "header.php";
?>

<!DOCTYPE html>
<html>
  <head>
    <!--
    This site was based on the Represent.LA project by:
    - Alex Benzer (@abenzer)
    - Tara Tiger Brown (@tara)
    - Sean Bonner (@seanbonner)

    Create a map for your startup community!
    https://github.com/abenzer/represent-map
    -->
    
    <link rel="stylesheet" href="normalize.css" type="text/css" />
    
    <title><?php echo $title_tag; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta charset="UTF-8">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700|Open+Sans:400,700' rel='stylesheet' type='text/css'>
    <!--<link href="./bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="./bootstrap/css/bootstrap-responsive.css" rel="stylesheet" type="text/css" />
    -->
    
    <link href="./bootstrap-new/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="./bootstrap-new/css/bootstrap-theme.css" rel="stylesheet" type="text/css" />
    <!--<link href="./bootstrap-new/css/bootstrap-responsive.css" rel="stylesheet" type="text/css" />-->
    
    <link rel="stylesheet" href="map.css?nocache=289671982568" type="text/css" />
    <link rel="stylesheet" media="only screen and (max-device-width: 768px)" href="mobile.css" type="text/css" />
    <!--<script src="./scripts/jquery-1.7.1.js" type="text/javascript" charset="utf-8"></script>-->
    <script src="./scripts/jquery-1.11.3.min.js" type="text/javascript" charset="utf-8"></script>
    
    
    <!--<script src="./bootstrap/js/bootstrap.js" type="text/javascript" charset="utf-8"></script>
    <script src="./bootstrap/js/bootstrap-typeahead.js" type="text/javascript" charset="utf-8"></script>-->
    
    <!-- TO DO: Usar outro typeahead (twitter?)-->
    <script src="./bootstrap-new/js/bootstrap.js" type="text/javascript" charset="utf-8"></script>
    <!--<script src="./bootstrap/js/bootstrap-typeahead.js" type="text/javascript" charset="utf-8"></script>-->
    
    <script src="./scripts/bootstrap3-typeahead.min.js" type="text/javascript" charset="utf-8"></script>
    <!--<link href="typeaheadjs.css" rel="stylesheet" type="text/css" />-->
    
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?libraries=places&sensor=false"></script>
    <script type="text/javascript" src="./scripts/label.js"></script>
<style type="text/css">


.navbar-nav>li {
        display: inline-block;
    }
    
    #typeahead_seach {
		border: 0;
		padding: 0;
    }

	
 .popover {
  width: 310px;
  max-width: 310px;
 }
 .modal {
    top: 45%;
}

 .modal-backdrop {
	z-index: 1020;
}

  .redPlaceHolder::-webkit-input-placeholder {
      color: #FF6666;
   }

   .redPlaceHolder:-moz-placeholder { /* Firefox 18- */
      color: #FF6666;  
   }

   .redPlaceHolder::-moz-placeholder {  /* Firefox 19+ */
      color: #FF6666;  
   }

   .redPlaceHolder:-ms-input-placeholder {  
      color: #FF6666;  
   }
   


</style>
    <script type="text/javascript">
      var map;
      var infowindow = null;
      var gmarkers = [];
      var markerTitles =[];
      var highestZIndex = 0;
      var agent = "default";
      var zoomControl = true;
      var googleMapsAutocomplete;
      var insertedMark;
      var googleMapsApiClickListener;
      var fullAddress = {
       "street_name" :"",
       "street_number" : "",
       "neighborhood": "", //Bairro?
       "city" : "", 
       "state" : "", //Estado?
       "country" : "",
       "postal_code": "",
      
      };
      

		
      //TO DO: Ver quais funções ficam em global
      function updateAddressFields() {
       //alert(fullAddress.street_name);
       
       //Reset values
       //TO DO: Ver jeito mais fácil de consertar isto
       //#*#*#*#*#*#*#*#*#*#*#*#* BUG: DEPOIS DE MOVER O PIN, DAR OK, ENTRAR NO FORM, SAIR DO FORM E CLICAR EM ADD SOMETHING O ENDEREÇO APARECE ERRADO
       $('#add_address_street').val("");
       $('#add_address_number').val("");
       $('#add_address_neighborhood').val("");
       $('#add_address_city').val("");
       $('#add_address_state').val("");
       $('#add_address_postal_code').val("");
       
       
       
       $('#add_address_street').val(fullAddress.street_name);
       $('#add_address_number').val(fullAddress.street_number);
       $('#add_address_neighborhood').val(fullAddress.neighborhood);
       $('#add_address_city').val(fullAddress.city);
       $('#add_address_state').val(fullAddress.state);
       $('#add_address_postal_code').val(fullAddress.postal_code);
       $('#add_lat').val(insertedMark.getPosition().lat());
       $('#add_long').val(insertedMark.getPosition().lng());
      }
      
      
      
      
      //TO DO: consertar detecção de browser mobile e tablet (dois ifs desnecessários também)
      // detect browser agent
      $(document).ready(function(){
        if(navigator.userAgent.toLowerCase().indexOf("iphone") > -1 || navigator.userAgent.toLowerCase().indexOf("ipod") > -1) {
          agent = "iphone";
          zoomControl = false;
        }
        if(navigator.userAgent.toLowerCase().indexOf("ipad") > -1) {
          agent = "ipad";
          zoomControl = false;
        }
         $('[data-toggle="tooltip"]').tooltip();
         $('[data-toggle="popover"]').popover();
         
         //TO DO: Colocar autocomplete na inserção de pontos com google maps autocomplete + twitter typeahead
         
         //Set input size to placeholder text
         $("#input-address").attr('size', $("#input-address").attr('placeholder').length);
         

         


          
          
         //TO DO: Consertar formatacação do popover
         $('#add_button').popover({
          html : true,
          placement : "bottom",
          trigger: "click",
          container :"body",
          content: function() {
           return $("#address_dialog_body").html();
          }
          
         });
         
         
         
         

          

         
         $('#add_button').on('click', function () {
          //$('#map_canvas').css('cursor', 'crosshair');
          /*$('#input-address').focus();
          $('#map_canvas').css('cursor', 'crosshair');
          alert('ma'+$('#newaddressOkButton').attr());
          console.log(JSON.stringify( $('#newaddressOkButton').attr(), null, 4));
          $('#newaddressOkButton').attr("value","ASDSADSDAD");
          */
          var googleMapsApiClickListener = google.maps.event.addListener(map, 'click', function(event) {
           placeNewAddressMarker(event.latLng,true);
          });
       
          $('.popover #newaddressOkButton').on('click', function (e) {
           if (typeof insertedMark == 'undefined') {
			if ($(".popover #input-address").val()) {
				//alert("not emp");
				geocode($(".popover #input-address").val());
				e.stopPropagation();
			
			} else {
				//alert("emp");
				//$(".popover #input-address").attr('placeholder','You have to write an address');
				$(".popover #input-address").addClass("redPlaceHolder");
				$(".popover #input-address").focus();
				/////geocode($(".popover #input-address").val());
				e.stopPropagation();
			}

           } else {
			//alert("ASDA");
			updateAddressFields();
			$('.popover ').popover('hide');
           }
          });
          
          $(document).keyup(function(e) {
           //alert("keypress");
           if(e.keyCode == 27) {
            //alert("keyESCpress");
            google.maps.event.removeListener(googleMapsApiClickListener);
            $('.popover ').popover('hide');
           }
          });
   
          $(".popover #input-address").on("keypress", function(e) {
           if(e.which == 13) {
            geocode($(this).val());
            //alert ($(this).val());
           }
            //alert("keypressed");
          });

           $(".popover #input-address").focus();
          
         });
         
      /*var tempTest = document.getElementById("address_dialog_body");
      alert(tempTest.innerHTML);
      document.getElementById("input-address").placeholder="CBA";
      document.getElementById("input-address").value="ABC";
      $('#input-address').attr('value','XXX');
      //document.getElementById("input-address").setAttribute("value","ABC");
      alert(tempTest.innerHTML);
      */   
         function placeNewAddressMarker(location,doReverseGeocode) {
          //var geoDecodedAddress;
           if ( insertedMark ) {
             insertedMark.setPosition(location);
           } else {
             insertedMark = new google.maps.Marker({
               position: location,
               draggable: true,
               map: map
             });
             google.maps.event.addListener(insertedMark, 'dragend', function () {
              var newPosition = insertedMark.getPosition();
              reverseGeocode(newPosition);
              map.setCenter(newPosition);
             });
           }
           map.setCenter(location);
           if (doReverseGeocode == true) {
            reverseGeocode(location);
           }

         }

        function updateAddressPopOver(updatedVal) {
         //*Workaround para problema de mudanca de valor de input dentro do popover!
          var element = document.getElementById("input-address");
          element.value=updatedVal;
          document.getElementById("input-address").setAttribute("value",element.value);
          $('#add_button').data('bs.popover').setContent();
          $('.popover #newaddressOkButton').on('click', function () {
           //alert('clicked me');
           //alert($('.popover #input-address').val());
           updateAddressFields();
           $('.popover ').popover('hide');
           //$('#add_address').val($('.popover #input-address').val());
          });
         
          $(".popover #input-address").on("keypress", function(e) {
           if(e.which == 13) {
            geocode($(this).val());
            //alert ($(this).val());
           }
            //alert("keypressed");
          });   
          //*Fim do workaround!
        }
        
        //LatLng to Address
       function reverseGeocode (latLng) {
        var geocoder;
        var address;
        geocoder = new google.maps.Geocoder();
        //TO DO: Colocar variável "region" como opicional. E colocar a variável "bounds" como opicional.
        //*TO DO: Variável "region" do Brasil = BR
        geocoder.geocode( { 'latLng': latLng}, function(results, status) {
         if (status == google.maps.GeocoderStatus.OK) {
          var i;
          for (i=0;i< results[0].address_components.length; i++) {
            if (results[0].address_components[i].types[0] == "street_number") {
             fullAddress.street_number = results[0].address_components[i].long_name;
            }
            if (results[0].address_components[i].types[0] == "route") {
             fullAddress.street_name = results[0].address_components[i].long_name;
            }
            if (results[0].address_components[i].types[0] == "intersection") {
             fullAddress.street_name = results[0].address_components[i].long_name;
            }
            if (results[0].address_components[i].types[0] == "neighborhood") {
             fullAddress.neighborhood = results[0].address_components[i].long_name;
            }
            if (results[0].address_components[i].types[0] == "locality") {
             fullAddress.city= results[0].address_components[i].long_name;
            }
            if (results[0].address_components[i].types[0] == "administrative_area_level_1") {
             fullAddress.state = results[0].address_components[i].long_name;
            }
            if (results[0].address_components[i].types[0] == "country") {
             fullAddress.country = results[0].address_components[i].long_name;
            }
            if (results[0].address_components[i].types[0] == "postal_code") {
             fullAddress.postal_code = results[0].address_components[i].long_name;
            }
          }
          ////////////////////////////////// OTIMO DEBUG console.dir(fullAddress);
          updateAddressPopOver(results[0].formatted_address);
          return results[0].formatted_address;
         } else {
          return false;
          alert("Geocode was not successful for the following reason: " + status);
         }
        });
       }         
         
         
        
       /*$('#add_address').on('blur', function () {
        var resultado;
        alert ($(this).val());
        resultado = geocode($(this).val());
        //#modal_add
        alert (resultado.latitude);
        alert ("over");
       });
       */
       
       

       
       //Addreess to LatLng
       function geocode (address) {
        var geocoder;
        var latitude;
        var longitude;
        var location;
        geocoder = new google.maps.Geocoder();
        //TO DO: Colocar variável "region" como opicional. E colocar a variável "bounds" como opicional.
        //*TO DO: Variável "region" do Brasil = BR
        //TO DO: No retorno da função geocoding identificar quando for "partial_match" e falar para o usuário selecionar manualmente
        //TO DO: ?Autocomplete de endereço para o usuário (Estilo google maps)?
        geocoder.geocode( { 'address': address}, function(results, status) {
         ///alert('ok1');
         if (status == google.maps.GeocoderStatus.OK) {
          //alert('ok');
          placeNewAddressMarker(results[0].geometry.location,false);
           /*map.setCenter(results[0].geometry.location);
           var marker = new google.maps.Marker({
               map: map,
               position: results[0].geometry.location
           });
           
           latitude = results[0].geometry.location.lat();
           longitude = results[0].geometry.location.lng();
           location = {
            "latitude" : latitude,
            "longitude" : longitude
           };
           alert ("lat" + location.latitude + "long" + location.longitude);
           return "aaa"; */
           var i;
           for (i=0;i< results[0].address_components.length; i++) {
            if (results[0].address_components[i].types[0] == "street_number") {
             fullAddress.street_number = results[0].address_components[i].long_name;
            }
            if (results[0].address_components[i].types[0] == "route") {
             fullAddress.street_name = results[0].address_components[i].long_name;
            }
            if (results[0].address_components[i].types[0] == "intersection") {
             fullAddress.street_name = results[0].address_components[i].long_name;
            }
            if (results[0].address_components[i].types[0] == "neighborhood") {
             fullAddress.neighborhood = results[0].address_components[i].long_name;
            }
            if (results[0].address_components[i].types[0] == "locality") {
             fullAddress.city= results[0].address_components[i].long_name;
            }
            if (results[0].address_components[i].types[0] == "administrative_area_level_1") {
             fullAddress.state = results[0].address_components[i].long_name;
            }
            if (results[0].address_components[i].types[0] == "country") {
             fullAddress.country = results[0].address_components[i].long_name;
            }
            if (results[0].address_components[i].types[0] == "postal_code") {
             fullAddress.postal_code = results[0].address_components[i].long_name;
            }
           }
           console.dir(fullAddress);
          } else {
           return false;
           alert("Geocode was not successful for the following reason: " + status);
         }
        });
       }
       
       
       
       
       
       
       
       
       
       
       
       

       
       
       /*$('#modal_add').on('show.bs.modal', function () {
        alert("AAAA"+googleMapsApiClickListener);
       });
       
       */
       
       
       $('#modal_add').on('hidden.bs.modal', function () {
        $("#modal_addform p").css("display", "block");
        $("#modal_addform fieldset").css("display", "block");
        $("#modal_addform .btn-primary").css("display", "block");
         //alert("AAAA"+$(document).googleMapsApiClickListener);
         //google.maps.event.removeListener(googleMapsApiClickListener);
        //$('#add_button').popover('show');
         //alert("BBBB"+googleMapsApiClickListener.toSource());
       })
       
       
       
      });

      
      

      // resize marker list onload/resize
      $(document).ready(function(){
        resizeList()
      });
      $(window).resize(function() {
        resizeList();
      });

      // resize marker list to fit window
      function resizeList() {
        newHeight = $('html').height() - $('#topbar').height();
        $('#list').css('height', newHeight + "px");
        $('#menu').css('margin-top', $('#topbar').height());
      }


      // initialize map
      function initialize() {
        // set map styles
        var mapStyles = [
         {
            featureType: "road",
            elementType: "geometry",
            stylers: [
              { hue: "#8800ff" },
              { lightness: 100 }
            ]
          },{
            featureType: "road",
            stylers: [
              { visibility: "on" },
              { hue: "#91ff00" },
              { saturation: -62 },
              { gamma: 1.98 },
              { lightness: 45 }
            ]
          },{
            featureType: "water",
            stylers: [
              { hue: "#005eff" },
              { gamma: 0.72 },
              { lightness: 42 }
            ]
          },{
            featureType: "transit.line",
            stylers: [
              { visibility: "off" }
            ]
          },{
            featureType: "administrative.locality",
            stylers: [
              { visibility: "on" }
            ]
          },{
            featureType: "administrative.neighborhood",
            elementType: "geometry",
            stylers: [
              { visibility: "simplified" }
            ]
          },{
            featureType: "landscape",
            stylers: [
              { visibility: "on" },
              { gamma: 0.41 },
              { lightness: 46 }
            ]
          },{
            featureType: "administrative.neighborhood",
            elementType: "labels.text",
            stylers: [
              { visibility: "on" },
              { saturation: 33 },
              { lightness: 20 }
            ]
          }
        ];

        // set map options
        var myOptions = {
          zoom: 11,
          //minZoom: 10,
          center: new google.maps.LatLng(<?php echo $lat_lng; ?>),
          mapTypeId: google.maps.MapTypeId.ROADMAP,
          streetViewControl: false,
          mapTypeControl: false,
          panControl: false,
          zoomControl: zoomControl,
          styles: mapStyles,
          zoomControlOptions: {
            style: google.maps.ZoomControlStyle.SMALL,
            position: google.maps.ControlPosition.LEFT_CENTER
          }
        };
        map = new google.maps.Map(document.getElementById('map_canvas'), myOptions);
        zoomLevel = map.getZoom();

        // prepare infowindow
        infowindow = new google.maps.InfoWindow({
          content: "holding..."
        });
        
        //TO DO: Ver nível ideal de zoom para mostrar label. Hoje 20.
        // only show marker labels if zoomed in
        google.maps.event.addListener(map, 'zoom_changed', function() {
          zoomLevel = map.getZoom();
          if(zoomLevel <= 20) {
            $(".marker_label").css("display", "none");
          } else {
            $(".marker_label").css("display", "inline");
          }
        });

        // markers array: name, type (icon), lat, long, description, uri, address
        markers = new Array();
        <?php
        //TO DO: Types dinâmicos definidos pelo usuário.
         $typesFile = file_get_contents ($typesFileName);
         //print_r($types);
          $types = json_decode($typesFile);
          //echo "SADFASDFSADFDSAFASD";
          //print_r($types);
          
          $marker_id = 0;
          foreach ($types->categories as $type) {
           //print_r($type);
           //echo $type->name;
           $places = mysql_query("SELECT * FROM places WHERE approved='1' AND type='$type->name' ORDER BY title");
           $places_total = mysql_num_rows($places);
           while($place = mysql_fetch_assoc($places)) {
             $place[title] = htmlspecialchars_decode(addslashes(htmlspecialchars($place[title])));
             $place[description] = str_replace(array("\n", "\t", "\r"), "", htmlspecialchars_decode(addslashes(htmlspecialchars($place[description]))));
             $place[uri] = addslashes(htmlspecialchars($place[uri]));
             $place[address] = htmlspecialchars_decode(addslashes(htmlspecialchars($place[address])));
             //TO DO: Transformar este echo em objeto JSON  e fazer javascript certo.
             if ($type->icon) {
             echo "
               markers.push(['".$place[title]."', '".$place[type]."', '".$place[lat]."', '".$place[lng]."', '".$place[description]."', '".$place[uri]."', '".$place[address]."', '".$type->icon."']);
               markerTitles[".$marker_id."] = '".$place[title]."';
             ";
             } else {
               echo "
               markers.push(['".$place[title]."', '".$place[type]."', '".$place[lat]."', '".$place[lng]."', '".$place[description]."', '".$place[uri]."', '".$place[address]."', '']);
               markerTitles[".$marker_id."] = '".$place[title]."';
              ";
             }
             $count[$place[type]]++;
             $marker_id++;
           }           
          }
          //exit;
          
          
          /*$types = Array(
              Array('startup', 'Startups'),
              Array('accelerator','Accelerators'),
              Array('incubator', 'Incubators'),
              Array('coworking', 'Coworking'),
              Array('investor', 'Investors'),
              Array('service', 'Consulting'),
              Array('hackerspace', 'Hackerspaces'),
              Array('event', 'Events'),
              );
          $marker_id = 0;
          foreach($types as $type) {
            $places = mysql_query("SELECT * FROM places WHERE approved='1' AND type='$type[0]' ORDER BY title");
            $places_total = mysql_num_rows($places);
            while($place = mysql_fetch_assoc($places)) {
              $place[title] = htmlspecialchars_decode(addslashes(htmlspecialchars($place[title])));
              $place[description] = str_replace(array("\n", "\t", "\r"), "", htmlspecialchars_decode(addslashes(htmlspecialchars($place[description]))));
              $place[uri] = addslashes(htmlspecialchars($place[uri]));
              $place[address] = htmlspecialchars_decode(addslashes(htmlspecialchars($place[address])));
              //TO DO: Transformar este echo em objeto JSON  e fazer javascript certo.
              echo "
                markers.push(['".$place[title]."', '".$place[type]."', '".$place[lat]."', '".$place[lng]."', '".$place[description]."', '".$place[uri]."', '".$place[address]."']);
                markerTitles[".$marker_id."] = '".$place[title]."';
              ";
              $count[$place[type]]++;
              $marker_id++;
            }
          }*/
        ?>

        // add markers
        //TO DO: Após consertar PHP para objeto JSON, consertar a partir daqui também se necessário.
        jQuery.each(markers, function(i, val) {
          infowindow = new google.maps.InfoWindow({
            content: ""
          });

          // offset latlong ever so slightly to prevent marker overlap
          rand_x = Math.random();
          rand_y = Math.random();
          val[2] = parseFloat(val[2]) + parseFloat(parseFloat(rand_x) / 6000);
          val[3] = parseFloat(val[3]) + parseFloat(parseFloat(rand_y) / 6000);

          // show smaller marker icons on mobile
          //TO DO: consertar aqui após consertar detecção de browser mobile...
          if(agent == "iphone") {
            var iconSize = new google.maps.Size(16,19);
          } else {
            iconSize = null;
          }

          // build this marker
          // TO DO: Aqui que é setado o ícone do marker. Permitir alterar?
          if (val[7]) {
           var markerImage = new google.maps.MarkerImage("./images/icons/"+val[7]+".png", null, null, null, iconSize);
          } else {
           //TO DO: Alterar imagem padrão do icone (startup.png)
           var markerImage = new google.maps.MarkerImage("./images/icons/startup.png", null, null, null, iconSize);
          }
          var marker = new google.maps.Marker({
            position: new google.maps.LatLng(val[2],val[3]),
            map: map,
            title: '',
            clickable: true,
            infoWindowHtml: '',
            zIndex: 10 + i,
            icon: markerImage
          });
          marker.type = val[1];
          //TO DO: Ver o que esse gmarkers.push faz.
          gmarkers.push(marker);

          // add marker hover events (if not viewing on mobile)
          if(agent == "default") {
            google.maps.event.addListener(marker, "mouseover", function() {
              this.old_ZIndex = this.getZIndex();
              this.setZIndex(9999);
              $("#marker"+i).css("display", "inline");
              $("#marker"+i).css("z-index", "99999");
            });
            google.maps.event.addListener(marker, "mouseout", function() {
              if (this.old_ZIndex && zoomLevel <= 15) {
                this.setZIndex(this.old_ZIndex);
                $("#marker"+i).css("display", "none");
              }
            });
          }

          // format marker URI for display and linking
          var markerURI = val[5];
          if(markerURI.substr(0,7) != "http://") {
            markerURI = "http://" + markerURI;
          }
          var markerURI_short = markerURI.replace("http://", "");
          var markerURI_short = markerURI_short.replace("www.", "");

          // add marker click effects (open infowindow)
          // TO DO: Alterar aqui quando tiver definido quais campos a serem exibidos ao clicar.
          google.maps.event.addListener(marker, 'click', function () {
            infowindow.setContent(
              "<div class='marker_title'>"+val[0]+"</div>"
              + "<div class='marker_uri'><a target='_blank' href='"+markerURI+"'>"+markerURI_short+"</a></div>"
              + "<div class='marker_desc'>"+val[4]+"</div>"
              + "<div class='marker_address'>"+val[6]+"</div>"
            );
            infowindow.open(map, this);
          });

          // add marker label
          var latLng = new google.maps.LatLng(val[2], val[3]);
          var label = new Label({
            map: map,
            id: i
          });
          label.bindTo('position', marker);
          label.set("text", val[0]);
          label.bindTo('visible', marker);
          label.bindTo('clickable', marker);
          label.bindTo('zIndex', marker);
        });


        // zoom to marker if selected in search typeahead list
        //TO DO: Mudar forma de pesquisa. Pesquisa por instituição, Pesquisa por cursos (destacar todos que tenham o curso desejado). Pesquisar por períodos (mostrar somente o dos períodos). etc..
        //TO DO: Consertar Typeahead colocando o do twitter
	 
	   
	   var statess = ['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California',
  'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii',
  'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana',
  'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota',
  'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire',
  'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota',
  'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island',
  'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont',
  'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'
];
        
        $('#typeahead_seach .typeahead').typeahead({
          //source: markerTitles,
		source: statess,
          onselect: function(obj) {
            marker_id = jQuery.inArray(obj, markerTitles);
            if(marker_id > -1) {
              map.panTo(gmarkers[marker_id].getPosition());
              map.setZoom(15);
              google.maps.event.trigger(gmarkers[marker_id], 'click');
            }
		  alert("ASDF");
            $("#search").val("");
          }
        });
        
      }


      // zoom to specific marker
      function goToMarker(marker_id) {
        if(marker_id) {
          map.panTo(gmarkers[marker_id].getPosition());
          map.setZoom(15);
          google.maps.event.trigger(gmarkers[marker_id], 'click');
        }
      }

      // toggle (hide/show) markers of a given type (on the map)
      function toggle(type) {
        if($('#filter_'+type).is('.inactive')) {
          show(type);
        } else {
          hide(type);
        }
      }

      // hide all markers of a given type
      function hide(type) {
        for (var i=0; i<gmarkers.length; i++) {
          if (gmarkers[i].type == type) {
            gmarkers[i].setVisible(false);
          }
        }
        $("#filter_"+type).addClass("inactive");
      }

      // show all markers of a given type
      function show(type) {
        for (var i=0; i<gmarkers.length; i++) {
          if (gmarkers[i].type == type) {
            gmarkers[i].setVisible(true);
          }
        }
        $("#filter_"+type).removeClass("inactive");
      }

      // toggle (hide/show) marker list of a given type
      function toggleList(type) {
        $("#list .list-"+type).toggle();
      }

      
      // hover on list item
      //TO DO: No hover do mouse, além de mostrar o label também animar o ícone.
      function markerListMouseOver(marker_id) {
        $("#marker"+marker_id).css("display", "inline");
      }
      function markerListMouseOut(marker_id) {
        $("#marker"+marker_id).css("display", "none");
      }

      google.maps.event.addDomListener(window, 'load', initialize);
    </script>

    <?php echo $head_html; ?>
  </head>
  <body>

    <!-- display error overlay if something went wrong -->
    <?php echo $error; ?>

    <!-- facebook like button code -->
    <div id="fb-root"></div>
    <script>
     //TO DO: Alterar ícone/link do Facebook.
     (function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=421651897866629";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>

    <!-- google map -->
    <div id="map_canvas"></div>

    <!-- topbar -->
    <nav class="navbar navbar-default navbar-fixed-top" id="topbar">
		<div class="container-fluid">
			<div class='navbar-header'>
				<a class="navbar-brand logo" href="./">
					<!--TO DO: Alterar Logo -->
					<img src="images/logo.png" alt="" />
				</a>
			</div>
			<!--
			Deleted twitter and FB nvabar goes here
			-->
			<div class="nav navbar-nav navbar-left">
				<ul class="nav navbar-nav buttons">
					<li id="about_li-button" style="margin-left: 5px; margin-right: 5px;">
						<p class="navbar-btn">
							<a href="#modal_info" class="btn btn-large btn-info" data-toggle="modal"><span aria-hidden="true" class="glyphicon glyphicon-info-sign"></span>&nbsp;About this Map</a>
						</p>
						
					</li>
					<li id="add_li-button" style="margin-left: 5px; margin-right: 5px;">
						<p class="navbar-btn">
							<!--#################################################################################-->
							<a id="add_button" href="#" class="btn btn-large btn-success" role="button"><span aria-hidden="true" class="glyphicon glyphicon-plus-sign"></span>&nbsp;Add Something</a>
							<!--<a href="#" class="btn btn-large btn-success" data-target="#modal_add" data-toggle="modal"><i class="icon-plus-sign icon-white"></i>Add Something</a>
						-->
						</p>
					</li>
					<li style="margin-left: 15px; max-width: 200px">
						<div class="search navbar-right navbar-form " id="typeahead_seach">
							<!-- TO DO: Colocar autocomplete-->
							<input class="typeahead form-control search-query" type="text" name="search" id="search" data-provide="typeahead" placeholder="Search for companies..." autocomplete="off" />
						</div>
					</li>
				</ul>
			</div>
		</div>
	</nav>

    <!-- right-side gutter -->
    <div class="menu" id="menu">
      <ul class="list" id="list">
        <?php
        // TO DO: Categorias dinâmicas.
          /* $types = Array(
              Array('startup', 'Startups'),
              Array('accelerator','Accelerators'),
              Array('incubator', 'Incubators'),
              Array('coworking', 'Coworking'),
              Array('investor', 'Investors'),
              Array('service', 'Consulting'),
              Array('hackerspace', 'Hackerspaces')
              );
                      
             */ 
             
             
             

             
          $marker_id = 0;
          foreach ($types->categories as $type) {
          //foreach($types as $type) {
             // TO DO: Retirar eventos?
            $markers = mysql_query("SELECT * FROM places WHERE approved='1' AND type='$type->name' ORDER BY title");
            $markers_total = mysql_num_rows($markers);
            if ($type->icon) {
             echo "
               <li class='category'>
                 <div class='category_item'>
                   <div class='category_toggle' onClick=\"toggle('$type->name')\" id='filter_$type->name'></div>
                   <a href='#' onClick=\"toggleList('$type->name');\" class='category_info'><img src='./images/icons/$type->icon.png' alt='' />$type->name<span class='total'> ($markers_total)</span></a>
                 </div>
                 <ul class='list-items list-$type->name'>
             ";
             while($marker = mysql_fetch_assoc($markers)) {
               echo "
                   <li class='".$marker[type]."'>
                     <a href='#' onMouseOver=\"markerListMouseOver('".$marker_id."')\" onMouseOut=\"markerListMouseOut('".$marker_id."')\" onClick=\"goToMarker('".$marker_id."');\">".$marker[title]."</a>
                   </li>
               ";
               $marker_id++;
             }
             echo "
                 </ul>
               </li>
             ";
            } else {
             //TO DO: Mudar ícone default
             echo "
               <li class='category'>
                 <div class='category_item'>
                   <div class='category_toggle' onClick=\"toggle('$type->name')\" id='filter_$type->name'></div>
                   <a href='#' onClick=\"toggleList('$type->name');\" class='category_info'><img src='./images/icons/startup.png' alt='' />$type->name<span class='total'> ($markers_total)</span></a>
                 </div>
                 <ul class='list-items list-$type->name'>
             ";
             while($marker = mysql_fetch_assoc($markers)) {
               echo "
                   <li class='".$marker[type]."'>
                     <a href='#' onMouseOver=\"markerListMouseOver('".$marker_id."')\" onMouseOut=\"markerListMouseOut('".$marker_id."')\" onClick=\"goToMarker('".$marker_id."');\">".$marker[title]."</a>
                   </li>
               ";
               $marker_id++;
             }
             echo "
                 </ul>
               </li>
             ";
            }
          }
        ?>
        <li class="blurb"><?php echo $blurb; ?></li>
        <li class="attribution">
          <!-- per our license, you may not remove this line -->
          <?php //TO DO: Ver o que é isso e se pode tirar
          echo $attribution;?>
        </li>
      </ul>
    </div>

    <!-- more info modal -->
    <div class="modal hide" id="modal_info">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <h3>About this Map</h3>
      </div>
      <div class="modal-body">
        <p>
          We built this map to connect and promote the tech startup community
          in our beloved Los Angeles. We've seeded the map but we need
          your help to keep it fresh. If you don't see your company, please
          <?php if($sg_enabled) { ?>
            <a href="#modal_add_choose" data-toggle="modal" data-dismiss="modal">submit it here</a>.
          <?php } else { ?>
            <a href="#modal_add" data-toggle="modal" data-dismiss="modal">submit it here</a>.
          <?php } ?>
          Let's put LA on the map together!
        </p>
        <p>
        Questions? Feedback? Connect with us: <a href="http://www.twitter.com/<?php echo $twitter['username']; ?>" target="_blank">@<?php echo $twitter['username']; ?></a>
        </p>
        <p>
          If you want to support the LA community by linking to this map from your website,
          here are some badges you might like to use. You can also grab the <a href="./images/badges/LA-icon.ai">LA icon AI file</a>.
        </p>
        <ul class="badges">
          <li>
            <img src="./images/badges/badge1.png" alt="">
          </li>
          <li>
            <img src="./images/badges/badge1_small.png" alt="">
          </li>
          <li>
            <img src="./images/badges/badge2.png" alt="">
          </li>
          <li>
            <img src="./images/badges/badge2_small.png" alt="">
          </li>
        </ul>
        <p>
        <!-- TO DO: mudar -->
          This map was built with <a href="https://github.com/abenzer/represent-map">RepresentMap</a> - an open source project we started
          to help startup communities around the world create their own maps.
          Check out some <a target="_blank" href="http://www.representmap.com">startup maps</a> built by other communities!
        </p>
      </div>
      <div class="modal-footer">
        <a href="#" class="btn" data-dismiss="modal" style="float: right;">Close</a>
      </div>
    </div>



    <!--<div class="dialog hide" id="modal_preadd">
     
     <div class="modal-body">
      <div id="result"></div>
       <fieldset>
                <input type="text" class="input-xlarge" name="owner_name" id="add_owner_name" maxlength="100">
       </fieldset>
      </div>
      <div class="modal-footer">
          <button type="xxxxxxxxxxxxxxxxxxx" class="btn btn-primary">Ok</button>
          <a href="#" class="btn" data-dismiss="modal" style="float: right;">Close</a>
        </div>
     </div>
    -->
    

    

    
    
    <!-- preadd dialog -->
     <!--<div id="address_dialog_body" class="content-fluid hide">
      <input type="text" class="form-control" name="preaddress_name" id="input-address" placeholder="Type address or click on the map" value="">
      <a id="newaddressOkButton" href="#" data-toggle="modal" class="btn btn-large btn-success" role="button" data-target="#modal_add">ok</a>
     </div>
    -->
    <div id="address_dialog_body" class="form-inline hide">
		<div id="address_formgroup" class="form-group">
			<label class="sr-only" for="input-addresst">Place to Search</label>
			<div class="input-group">
				<input type="text" class="form-control" name="preaddress_name" id="input-address" placeholder="Type address or click on the map" value="">
				<span class="input-group-btn">
					<a id="newaddressOkButton" href="#" data-toggle="modal" class="btn btn-large btn-success" role="button" data-target="#modal_add">ok</a>
				</span>
			</div>
		</div>
     </div>
    
 
    
    
    
    
    
    
    
    <!-- Modal 
<div class="modal fade" id="modal_add" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title</h4>
      </div>
      <div class="modal-body">
      
          asdfasfsafsafasfsda
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
    
    -->
    
    
    
    
    
    
    
    
   
    
    
    <script>
       

       
       
       
       
      
       
       
       
      //****TO DO:*** Validar campos do form em javascript. Ver quais não são obrigatórios.
      //TO DO: Mudar submit fazendo o geocoding pelo usuário ANTES dele dar submit (e não o servidor)
      // add modal form submit
      $("#modal_addform").submit(function(event) {
        event.preventDefault();
        // get values
        var $form = $( this ),
            owner_name = $form.find( '#add_owner_name' ).val(),
            owner_email = $form.find( '#add_owner_email' ).val(),
            title = $form.find( '#add_title' ).val(),
            type = $form.find( '#add_type' ).val(),
            address_street = $form.find( '#add_address_street' ).val(),
            address_number = $form.find( '#add_address_number' ).val(),
            address_neighborhood = $form.find( '#add_address_neighborhood' ).val(),
            address_city = $form.find( '#add_address_city' ).val(),
            address_state = $form.find( '#add_address_state' ).val(),
            address_postal_code = $form.find( '#add_address_postal_code' ).val(),
            lat = $form.find( '#add_lat' ).val(),
            lng = $form.find( '#add_long' ).val(),
            uri = $form.find( '#add_uri' ).val(),
            description = $form.find( '#add_description' ).val(),
            url = $form.attr( 'action' );
            
            //geocode(address);
            
            
            
            

            
            
            
            
///alert('ok');

            
            
            
            
            
            
            
            
            
            
            
            
        // send data and get results
        // TO DO: Validar submit. E ver forma de confrontar dados já existentes. Além disso tentar evitar "DoS"...
        //////////////////$.post( url, { owner_name: owner_name, owner_email: owner_email, title: title, type: type, address_street: address_street, uri: uri, description: description },
        $.post( url, { owner_name : owner_name, owner_email : owner_email, title : title, type : type, address_street : address_street, address_number : address_number, address_neighborhood : address_neighborhood, address_city : address_city, address_state :   address_state, address_postal_code : address_postal_code, lat : lat, lng : lng, uri : uri, description : description, url :  url },
          function( data ) {
            var content = $( data ).find( '#content' );

            // if submission was successful, show info alert
            if(data == "success") {
              $("#modal_addform #result").html("We've received your submission and will review it shortly. Thanks!");
              $("#modal_addform #result").addClass("alert alert-info");
              $("#modal_addform p").css("display", "none");
              $("#modal_addform fieldset").css("display", "none");
              $("#modal_addform .btn-primary").css("display", "none");

            // if submission failed, show error
            } else {
              $("#modal_addform #result").html(data);
              $("#modal_addform #result").addClass("alert alert-danger");
              $("#modal_addform p").css("display", "none");
              $("#modal_addform fieldset").css("display", "none");
              $("#modal_addform .btn-primary").css("display", "none");
            }
          }
        );
      });
    </script>

    <!-- startup genome modal -->
    <!-- TO DO: Retirar isto? -->
    <div class="modal hide" id="modal_add_choose">
      <form action="add.php" id="modal_addform_choose" class="form-horizontal">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">×</button>
          <h3>Add something!</h3>
        </div>
        <div class="modal-body">
          <p>
            Want to add your company to this map? There are two easy ways to do that.
          </p>
          <ul>
            <li>
              <em>Option #1: Add your company to Startup Genome</em>
              <div>
                Our map pulls its data from <a href="http://www.startupgenome.com">Startup Genome</a>.
                When you add your company to Startup Genome, it will appear on this map after it has been approved.
                You will be able to change your company's information anytime you want from the Startup Genome website.
              </div>
              <br />
              <a href="http://www.startupgenome.com" target="_blank" class="btn btn-info">Sign in to Startup Genome</a>
            </li>
            <li>
              <em>Option #2: Add your company manually</em>
              <div>
                If you don't want to sign up for Startup Genome, you can still add your company to this map.
                We will review your submission as soon as possible.
              </div>
              <br />
          <a href="#modal_add" target="_blank" class="btn btn-info" data-toggle="modal" data-dismiss="modal">Submit your company manually</a>
            </li>
          </ul>
        </div>
      </form>
    </div>
    
    
    
    
     <!-- add something modal -->
    <div class="modal fade" id="modal_add" tabindex="-1" role="dialog" aria-labelledby="newPointModal">
     <div class="modal-dialog" role="document">
       <div class="modal-content">
       <form action="add.php" id="modal_addform" class="form-horizontal" role="form" method="post">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">×</button>
          <h3 class="modal-title" id="newPointModal">Add something!</h3>
        </div>
        <div class="modal-body" style="width:90%; position: relative; left: 2%;">
          <div id="result"></div>
          <fieldset>
            <div class="form-group ">
              <label class="col-xs-4 control-label" for="add_owner_name" style="align: left;">Your Name</label>
              <div class="col-xs-8">
                <input type="text" class="form-control" name="owner_name" id="add_owner_name" maxlength="100">
              </div>
            </div>
            <div class="form-group">
              <label class="col-xs-4 control-label" for="add_owner_email">Email</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="owner_email" id="add_owner_email" maxlength="100">
              </div>
            </div>
            <div class="form-group">
              <label class="col-xs-4 control-label" for="add_title">Company Name</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="title" id="add_title" maxlength="100" autocomplete="off">
              </div>
            </div>
            <div class="form-group">
              <label class="col-xs-4 control-label" for="add_type">Company Type</label>
              <div class="col-xs-8">
                <select name="type" id="add_type" class="form-control input-xlarge">
                 <?php
                  foreach ($types->categories as $type) {
                   echo '<option value="'.$type->name.'">'.$type->name.'</option>';
                  }
                  ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-xs-4 control-label" for="add_address_street">Address (street)</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="address" id="add_address_street" autocomplete="off">
              </div>
            </div>
             <div class="form-group">
              <label class="col-xs-4 control-label" for="add_address_number">Address (street number)</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="address" id="add_address_number" autocomplete="off">
              </div>
             </div>
             <div class="form-group">
              <label class="col-xs-4 control-label" for="add_address_neighborhood">Neighborhood</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="address" id="add_address_neighborhood" autocomplete="off">
              </div>
             </div>
             <div class="form-group">
              <label class="col-xs-4 control-label" for="add_address_city">City</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="address" id="add_address_city" autocomplete="off">
              </div>
             </div>
             <div class="form-group">
              <label class="col-xs-4 control-label" for="add_address_state">State</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="address" id="add_address_state" autocomplete="off">
              </div>
             </div>
             <div class="form-group">
              <label class="col-xs-4 control-label" for="add_address_postal_code">Postal Code</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="address" id="add_address_postal_code" autocomplete="off">
              </div>
             </div>
           <div class="form-group hide">
           <div class="col-xs-12">
            <div class="form-inline">
             <div class="form-group col-xs-6">
              <label class="control-label" for="add_lat">Lat</label>
              <input type="text" class="form-control input-xlarge" name="latitute" id="add_lat" autocomplete="off">
             </div>
             <div class="form-group col-xs-6">
              <label class="control-label" for="add_long">Long</label>
              <input type="text" class="form-control input-xlarge" name="longitude" id="add_long" autocomplete="off">
             </div>
            </div>
           </div>
          </div>
            
            <div class="form-group">
              <label class="col-xs-4 control-label" for="add_uri">Website URL</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" id="add_uri" name="uri" placeholder="http://">
                <p class="help-block">
                  Should be your full URL with no trailing slash, e.g. "http://www.yoursite.com"
                </p>
              </div>
            </div>
            <div class="form-group">
              <label class="col-xs-4 control-label" for="add_description">Description</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" id="add_description" name="description" maxlength="150">
                <p class="help-block">
                  Brief, concise description. What's your product? What problem do you solve? Max 150 chars.
                </p>
              </div>
            </div>
          </fieldset>
          
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Submit for Review</button>
          <a href="#" class="btn" data-dismiss="modal" style="float: right;">Close</a>
        </div>
        </form>
      </div>
      </div>
    </div>

  </body>
</html>
