<?php
include "header.php";


if(isset($_GET['place_id'])) {
  $place_id = htmlspecialchars($_GET['place_id']); 
} else if(isset($_POST['place_id'])) {
  $place_id = htmlspecialchars($_POST['place_id']);
} else {
  exit; 
}


// get place info
$place_query = mysql_query("SELECT * FROM places WHERE id='$place_id' LIMIT 1");
if(mysql_num_rows($place_query) != 1) { exit; }
$place = mysql_fetch_assoc($place_query);




function parseInput($value) {
  $value = htmlspecialchars($value, ENT_QUOTES);
  $value = str_replace("\r", "", $value);
  $value = str_replace("\n", "", $value);
  return $value;
}





// do place edit if requested
$task = "";
if (isset($_POST['task'])) {
	$task = parseInput($_POST['task']);
}
///$task = "doedit";

if($task == "doedit") {
	//echo "doEdit";
	//print_r($_POST);
	//trigger_error("Cannot divide by zero#####".print_r($_POST), E_USER_ERROR);
 $owner_name = mysql_real_escape_string(parseInput($_POST['add_owner_name']));
 $owner_email = mysql_real_escape_string(parseInput($_POST['add_owner_email']));
 $title = mysql_real_escape_string(parseInput($_POST['add_title']));
 $type = mysql_real_escape_string(parseInput($_POST['add_type']));
 $address_street = mysql_real_escape_string(parseInput($_POST['add_address_street']));
 $address_number = mysql_real_escape_string(parseInput($_POST['add_address_number']));
 $address_neighborhood = mysql_real_escape_string(parseInput($_POST['add_address_neighborhood']));
 $address_city = mysql_real_escape_string(parseInput($_POST['add_address_city']));
 $address_state = mysql_real_escape_string(parseInput($_POST['add_address_state']));
 $address_postal_code = mysql_real_escape_string(parseInput($_POST['add_address_postal_code']));
 $lat = mysql_real_escape_string(parseInput($_POST['mylat']));
 $lng = mysql_real_escape_string(parseInput($_POST['mylng']));
 $uri = mysql_real_escape_string(parseInput($_POST['add_uri']));
 $description = mysql_real_escape_string(parseInput($_POST['add_description']));
  //echo "antes query";
  mysql_query("UPDATE places SET title='$title', type='$type', lat='$lat', lng='$lng', address_street='$address_street', address_number='$address_number', address_neighborhood='$address_neighborhood', address_city='$address_city', address_state='$address_state', address_postal_code='$address_postal_code', uri='$uri', description='$description', owner_name='$owner_name', owner_email='$owner_email' WHERE id='$place_id' LIMIT 1") or die(mysql_error());
  //echo "depois query";
  // geocode
  //$hide_geocode_output = true;
  //include "../geocode.php";
  //echo "SADFAS";
  header("Location: index.php?view=$view&search=$search&p=$p");
  exit;
}


$typesFile = file_get_contents ("../".$typesFileName);
$types = json_decode($typesFile);

?>



<?php echo $admin_head; ?>

<form id="admin" class="form-horizontal" action="edit.php" role="form" method="post">
  <h1>
    Edit Place
  </h1>
  <fieldset>
  
  
  
  
  
            
            <div class="form-group ">
              <label class="col-xs-4 control-label" for="add_owner_name">Your Name</label>
              <div class="col-xs-8">
                <input type="text" class="form-control  input-xlarge" name="add_owner_name"  id="add_owner_name" maxlength="100" value="<?php echo $place['owner_name']?>">
              </div>
            </div>
            <div class="form-group">
              <label class="col-xs-4 control-label" for="add_owner_email">Email</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="add_owner_email" id="add_owner_email" maxlength="100"  value="<?php echo $place['owner_email']?>">
              </div>
            </div>
            <div class="form-group">
              <label class="col-xs-4 control-label" for="add_title">Company Name</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="add_title" id="add_title" maxlength="100" value="<?php echo $place['title']?>" autocomplete="off">
              </div>
            </div>
            <div class="form-group">
              <label class="col-xs-4 control-label" for="add_type">Company Type</label>
              <div class="col-xs-8">
                <select name="add_type" id="add_type" class="form-control input-xlarge">
                 <?php
                  foreach ($types->categories as $type) {
                   if ($place['type'] == $type->name) {
                    echo '<option value="'.$type->name.'" selected="selected">'.$type->name.'</option>';
                   } else {
                    echo '<option value="'.$type->name.'">'.$type->name.'</option>';
                   }
                  }
                  ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-xs-4 control-label" for="add_address_street">Address (street)</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="add_address_street" id="add_address_street" value="<?php echo $place['address_street']?>" autocomplete="off">
              </div>
            </div>
             <div class="form-group">
              <label class="col-xs-4 control-label" for="add_address_number">Address (street number)</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="add_address_number" id="add_address_number" value="<?php echo $place['address_number']?>" autocomplete="off">
              </div>
             </div>
             <div class="form-group">
              <label class="col-xs-4 control-label" for="add_address_neighborhood">Neighborhood</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="add_address_neighborhood" id="add_address_neighborhood" value="<?php echo $place['address_neighborhood']?>" autocomplete="off">
              </div>
             </div>
             <div class="form-group">
              <label class="col-xs-4 control-label" for="add_address_city">City</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="add_address_city" id="add_address_city" value="<?php echo $place['address_city']?>" autocomplete="off">
              </div>
             </div>
             <div class="form-group">
              <label class="col-xs-4 control-label" for="add_address_state">State</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="add_address_state" id="add_address_state" value="<?php echo $place['address_state']?>" autocomplete="off">
              </div>
             </div>
             <div class="form-group">
              <label class="col-xs-4 control-label" for="add_address_postal_code">Postal Code</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" name="add_address_postal_code" id="add_address_postal_code" value="<?php echo $place['address_postal_code']?>" autocomplete="off">
              </div>
             </div>
            
            
            <div class="form-group">
              <label class="col-xs-4 control-label" for="add_uri">Website URL</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" id="add_uri" name="add_uri" value="<?php echo $place['uri']?>" placeholder="http://">
                <p class="help-block">
                  Should be your full URL with no trailing slash, e.g. "http://www.yoursite.com"
                </p>
              </div>
            </div>
            <div class="form-group">
              <label class="col-xs-4 control-label" for="add_description">Description</label>
              <div class="col-xs-8">
                <input type="text" class="form-control input-xlarge" id="add_description" name="add_description" value="<?php echo $place['description']?>" maxlength="150">
                <p class="help-block">
                  Brief, concise description. What's your product? What problem do you solve? Max 150 chars.
                </p>
              </div>
            </div>
            
            <div class="form-group">
              <label class="col-xs-4  control-label" for="mylat">Latitude:</label>
                <div class="col-xs-8">
                 <input type="text" class="form-control" name="mylat" id="mylat" value="<?php echo $place['lat']?>" autocomplete="off">
                </div>
             </div>
            <div class="form-group">
                <label class="col-xs-4 control-label" for="mylng">Longitude:</label>
                <div class="col-xs-8">
                 <input type="text" class="form-control " name="mylng" id="mylng" value="<?php echo $place['lng']?>" autocomplete="off">
                </div>           
               </div>
            
            <div class="form-group">
             <label class="control-label" for="">Location</label>
              <div id="map" style="width:80%;height:300px;">
              </div>
            <script type="text/javascript">
              var map = new google.maps.Map( document.getElementById('map'), {
                zoom: 17,
                center: new google.maps.LatLng( <?php echo $place['lat']?>, <?php echo $place['lng']?> ),
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                streetViewControl: false,
                mapTypeControl: false
              });
              var marker = new google.maps.Marker({
                position: new google.maps.LatLng( <?php echo $place['lat']?>, <?php echo $place['lng']?> ),
                map: map,
                draggable: true
              });
              google.maps.event.addListener(marker, 'dragend', function(e){
                document.getElementById('mylat').value = e.latLng.lat().toFixed(6);
                document.getElementById('mylng').value = e.latLng.lng().toFixed(6);
              });
            </script>
            </div>

    <div class="form-actions">
      <button type="submit" class="btn btn-primary">Save Changes</button>
      <input type="hidden" name="task" value="doedit" />
      <input type="hidden" name="place_id" value="<?php echo $place['id']?>" />
      <input type="hidden" name="view" value="<?php echo $view?>" />
      <input type="hidden" name="search" value="<?php echo $search?>" />
      <input type="hidden" name="p" value="<?php echo $p?>" />
      <a href="index.php" class="btn" style="float: right;">Cancel</a>
    </div>
  </fieldset>
</form>



<?php echo $admin_foot; ?>
