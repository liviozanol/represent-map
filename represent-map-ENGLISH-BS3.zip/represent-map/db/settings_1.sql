

CREATE TABLE IF NOT EXISTS `settings` (
  `sg_lastupdate` int(14) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `settings` (`sg_lastupdate`) VALUES
(0);

